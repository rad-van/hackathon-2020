  Motobit PureASP file upload v2.0
With progress bar, chunk data reading and enhanced samples.
c 1998-2004 Antonin Foller, Motobit Software
http://www.motobit.com

  PureASP upload LICENSE

  PureASP upload (_upload.asp script) is a freeware with a limited use. 
It was created as a free promo code for Huge-ASP file upload - hi performance 
upload solution for ASP/IIS.

  You can use Pure-ASP upload without additional licenses
to upload files with size up to 10MB for free. Please include 
<A Href="http://www.motobit.com/help/scptutl/upload.asp">Pure-ASP file upload</A>
or similar text link to http://www.motobit.com on the web site using 
Pure-ASP upload.

  See PureASP upload - using, features, functionality, notes at
http://www.motobit.com/help/scptutl/pa38.htm  
  or local
mk:@MSITStore:%windir%\Help\ScptUtl.chm::/pa38.htm


  Huge-ASP upload and ScriptUtilities registration

  What do will you get if you register?
1. Enhanced Pure-ASP upload code, which lets your clients upload files
   with size up to 100MB and progress bar

2. Full version of HugeASP upload with
 - upload files from bytes to gigabytes with exciting performance
 - low memory consumption (10kBs/upload)
 - work with any code page (including utf-8, MAC, ANSI, OEM, etc.)
   see http://Motobit.cz/help/scptutl/cl68.htm
 - application/x-www-form-urlencoded handling with same performance
 - Header handling with several code pages
 - File state in progress bar (you will see uploading file names)
 - Enhanced SQL upload - up to 2GB to SQL binary data field

3. Other ScriptUtilities functionality
 - Huge-file download - unlimited size (2GB, also >2GB) with minimum
   server resources (memory, processor)
 - ByteArray class to hi-speed work with binary and conversions (HexString)
 - INI file work kernel and user library calls
 - Enhanced timing and script performance monitoring (up to 1ns)

  DISCLAIMER OF WARRANTY

  I worked a lot of time on PureASP upload code, but 
  THIS SOFTWARE AND THE ACCOMPANYING FILES ARE DELIVERED 
"AS IS" AND WITHOUT WARRANTIES AS TO PERFORMANCE 
OR MERCHANTABILITY OR ANY OTHER WARRANTIES 
WHETHER EXPRESSED OR IMPLIED. 
  

  DISTRIBUTION

  You can re-distribute PureASP upload as original pack 
(http://www.motobit.com/dlldownload/pASPUpl2.zip). You can also
re-distribute parts of this software, but every time with
this readme file and with notice about original location
(http://www.motobit.com)