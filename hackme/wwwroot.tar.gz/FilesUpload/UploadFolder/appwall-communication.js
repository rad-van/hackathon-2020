const Promise = require('bluebird');
const log = require('./logger');
const net = require('net');
const os = require('os');
const config = require('config');
const fs = require('fs');
const path = require('path');
const encryption = require('./appwall-encryption');
const messaging = require('./appwall-messaging');

Promise.promisifyAll(net);

class AppWallCommunication {
  constructor() {
    this.isConnected = false;
    this.data = '';
    this.messages = [];
    this.savedMessages = [];

    this.socket = new net.Socket();
    this.socket.setEncoding('utf8');

    this.socket.on('error', this.socketError.bind(this));
    this.socket.on('close', this.socketClosed.bind(this));
    this.socket.on('connect', this.socketConnected.bind(this));
    this.socket.on('data', this.socketData.bind(this));
  }

  socketError(error) {
    log.error('Socket error.', error);
  }

  socketClosed(hadError) {
    this.isConnected = false;
    const message = this.messages.shift();
    log.debug(`Socket Closed: Pulling message from queue to process. MessageQueue Length: ${this.messages.length}`);

    if (hadError) {
      log.error('Socket closed due to transmission error');
      message.reject('socket error');
      return;
    }

    if (message.response && message.response.resultCode === 401) {
      log.info('401 - Unauthenticated. Authenticating and trying message again.');

      // save messages for later
      this.savedMessages = this.messages;
      this.messages = [];
      log.debug(`Saved ${this.savedMessages.length} messages for after authentication.`);

      this.authenticate()
        .then(() => {
          // restore saved messages
          this.messages = this.savedMessages;
          this.savedMessages = [];
          log.debug(`Restored ${this.messages.length} messages now that authentication is complete.`);

          // put unsent message back on the queue
          this.messages.unshift(message);

          // put the new auth token into the messages left in queue
          // if it had one before
          this.messages.forEach((oldMessage) => {
            const messageParts = oldMessage.originalMessage.split('\t');
            if (messageParts[3] !== '') {
              messageParts[3] = messaging.authenticationToken;
            }
            oldMessage.originalMessage = messageParts.join('\t');
          });

          // we know there is at least one on the queue, connectAndSend it
          this.isConnected = true;
          this.messages[0].connectAndSend();
        })
        .catch((e) => {
          log.error('Unable to re-authenticate.', e);
        });
    } else {
      // response was good, resolve promise with response
      message.resolve(message.response);

      // trigger next message in queue to send if some are waiting
      if (this.messages.length > 0) {
        log.debug(`More messages in the queue, sending the next one. MessageQueue Length: ${this.messages.length}`);
        this.isConnected = true;
        this.messages[0].connectAndSend();
      }
    }
  }

  socketConnected() {
    log.info('Socket connected.');
  }

  socketData(data) {
    if (!data || data.length <= 0) {
      return;
    }

    // first check we have enough data for a header line
    this.data += data;

    const crlfPos = this.data.indexOf('\r\n');
    if (crlfPos !== -1) {
      // have a crlf parse header and see what to do
      const headerLine = this.data.substring(0, crlfPos);
      log.debug('Response:' + headerLine);
      this.data = this.data.substring(crlfPos + 2);

      const headerPieces = headerLine.split('\t');
      const bodySize = parseInt(headerPieces[3]) + 2; // +2 message body always? has a \r\n
      const messageBody = this.data.substring(0, bodySize);
      this.data = this.data.substring(bodySize);

      this.messages[0].response = {
        resultCode: parseInt(headerPieces[0]),
        serverVersion: headerPieces[1],
        bodySize: bodySize,
        headerMessage: headerPieces[5],
        messageBody: messageBody,
      };
    }
  }

  connect() {
    return this.socket.connectAsync(
      {
        host: process.env.APPWALL_IP || 'localhost',
        port: process.env.APPWALL_PORT || 8200,
      });
  }

  // build up a message to send and a promise to wait on for the response
  sendMessage(messageData, messageType) {
    // TODO: trim this smarter. To prevent massive post bodies in the log
    log.debug('Send:' + messageData.slice(0, 128));

    const message = {
      originalMessage: messageData,
      type: messageType,
    };

    this.messages.push(message);
    log.debug(`Putting new ${messageType} into queue. MessageQueue Length: ${this.messages.length}`);

    message.connectAndSend = () => {
      return this.connect()
        .then(() => {
          this.socket.write(message.originalMessage);
        })
        .catch((error) => {
          log.error('Error sending message.', error);
          throw error;
        });
    };

    return new Promise( (resolve, reject) => {
      message.resolve = resolve;
      message.reject = reject;
      if (!this.isConnected) {
        this.isConnected = true;
        log.debug(`Not connected. Sending message immediately. MessageQueue Length: ${this.messages.length}`);
        message.connectAndSend();
      } else {
        log.debug(`Socket busy. Message queued.  MessageQueue Length: ${this.messages.length}`);
      }
    });
  }

  authAuthenticate() {
    const authenticateMessage = messaging.buildRequestMessage(messaging.messageType.authAuthenticate, os.hostname());
    return this.sendMessage(authenticateMessage, 'authenticate');
  }

  authConnect(serverMachineName) {
    const connectMessage = messaging.buildRequestMessage(messaging.messageType.authConnect, serverMachineName);
    return this.sendMessage(connectMessage, 'connect');
  }

  authenticate() {
    // TODO: centralize this better
    if (!config.get('appwall.connectToProtocol')) {
      log.info('Running in development mode. Not connecting to AppWall custom protocol.');
      return Promise.resolve();
    }

    return this.authAuthenticate()
      .then((message) => {
        if (message.resultCode !== 200) {
          log.error('resultCode not 200. Authenticate step one (AUTHENTICATE) failed. ', message);
          return;
        }
        if (message.serverVersion !== config.get('vantage.clientVersion')) {
          log.error('Authenticate client/server version mismatch', message);
          // return; TODO: figure out how version mismatch applies in Vantage
        }

        const authResponsePieces = message.headerMessage.split(',');
        const encryptedClientName = encryption.encryptMachineName(os.hostname());
        const serverEncryptedClientName = authResponsePieces[0].substring(4); // skip key=
        if (encryptedClientName !== serverEncryptedClientName) {
          log.error('Invalid server encrypted client name', message);
          return;
        }

        const serverMachineName = authResponsePieces[1];

        log.info('AppWall authenticate step one (AUTHENTICATE) complete.');

        return this.authConnect(serverMachineName)
          .then((message) => {
            if (message.resultCode !== 200) {
              log.error('resultCode not 200. Authenticate step two (CONNECT) failed: ', message);
              return;
            }

            messaging.authenticationToken = message.headerMessage.substring(6); // skip token=
            log.info('AppWall authenticate step two (CONNECT) complete.');
          });
      })
      .catch((e) => {
        log.error('Unable to authenticate.', e);
      });
  }

  // TODO: The functions below should move out of this class!
  getDPTest(xmlMessage) {
    if (!config.get('appwall.connectToProtocol')) {
      log.info('Dev Mode: canned response to getDPTest');
      const cannedMessage = {
        resultCode: 200, // A sample return of a 200 status - with the error in the message
        messageBody: 'Connection to DP failed', // A sample message that would return from the Appwall
      };
      return Promise.resolve(cannedMessage);
    }

    const dpTest = messaging.buildRequestMessage(messaging.messageType.dpTest, null, xmlMessage);
    return this.sendMessage(dpTest, 'dpTest');
  }

  getIpAddresses() {
    if (!config.get('appwall.connectToProtocol')) {
      log.info('Dev Mode: canned response to getIpAddresses');
      const cannedData = fs.readFileSync(path.join(config.get('appwall.configFilePath'), 'IpAddresses.xml'));
      const cannedMessage = {
        messageBody: cannedData,
      };
      return Promise.resolve(cannedMessage);
    }

    const ipAddressesMessage = messaging.buildRequestMessage(messaging.messageType.ipAddresses);
    return this.sendMessage(ipAddressesMessage, 'ipAddresses');
  }

  getSystemStatistics() {
    if (!config.get('appwall.connectToProtocol')) {
      log.info('Dev Mode: canned response to getSystemStatistics');
      const cannedData = fs.readFileSync(path.join(config.get('appwall.configFilePath'), 'system-statistics.xml'));
      const cannedMessage = {
        messageBody: cannedData,
      };
      return Promise.resolve(cannedMessage);
    }

    const systemStatisticsMessage = messaging.buildRequestMessage(messaging.messageType.systemStatistics);
    return this.sendMessage(systemStatisticsMessage, 'systemStatistics');
  }

  getCommStatistics() {
    if (!config.get('appwall.connectToProtocol')) {
      log.info('Dev Mode: canned response to getCommStatistics');
      const cannedData = fs.readFileSync(path.join(config.get('appwall.configFilePath'), 'comm-statistics.xml'));
      const cannedMessage = {
        messageBody: cannedData,
      };
      return Promise.resolve(cannedMessage);
    }

    const commStatisticsMessage = messaging.buildRequestMessage(messaging.messageType.commStatistics);
    return this.sendMessage(commStatisticsMessage, 'commStatistics');
  }

  getIPGroupTest(xmlMessage) {
    if (!config.get('appwall.connectToProtocol')) {
      log.info('Dev Mode: canned response to getIPGroupTest');
      const cannedMessage = {
        messageBody: '1', // Last digit is 1=success, 2=excluded, 3=not in range
      };
      return Promise.resolve(cannedMessage);
    }

    const ipGroupTest = messaging.buildRequestMessage(messaging.messageType.ipGroupTest, null, xmlMessage);
    return this.sendMessage(ipGroupTest, 'ipGroupTest');
  }

  getManageAddresses() {
    if (!config.get('appwall.connectToProtocol')) {
      log.info('Dev Mode: canned response to getIpAddresses');
      const cannedData = fs.readFileSync(path.join(config.get('appwall.configFilePath'), 'ManageAddresses.xml'));
      const cannedMessage = {
        messageBody: cannedData,
      };
      return Promise.resolve(cannedMessage);
    }
    const manageAddresses = messaging.buildRequestMessage(messaging.messageType.manageAddresses);
    return this.sendMessage(manageAddresses, 'manageAddresses');
  }

  getUpdaterStatus() {
    if (!config.get('appwall.connectToProtocol')) {
      log.info('Dev Mode: canned response to getUpdaterStatus');
      const cannedData = fs.readFileSync(path.join(config.get('appwall.configFilePath'), 'UpdaterStatus.xml'));
      const cannedMessage = {
        messageBody: cannedData,
      };
      return Promise.resolve(cannedMessage);
    }
    const updaterGetStatus = messaging.buildRequestMessage(messaging.messageType.updaterGetStatus);
    return this.sendMessage(updaterGetStatus, 'updaterGetStatus');
  }

  getUpdaterVerList() {
    if (!config.get('appwall.connectToProtocol')) {
      log.info('Dev Mode: canned response to getUpdaterVerList');
      const cannedData = fs.readFileSync(path.join(config.get('appwall.configFilePath'), 'UpdaterVerList.xml'));
      const cannedMessage = {
        messageBody: cannedData,
      };
      return Promise.resolve(cannedMessage);
    }
    const updaterGetVerList = messaging.buildRequestMessage(messaging.messageType.updaterGetVerList);
    return this.sendMessage(updaterGetVerList, 'updaterGetVerList');
  }

  getUpdaterAbort() {
    if (!config.get('appwall.connectToProtocol')) {
      log.info('Dev Mode: canned response to getUpdaterAbort');
      const cannedMessage = {
        resultCode: 200, // A sample return of a 200 status - with the error in the message
      };
      return Promise.resolve(cannedMessage);
    }
    const updaterAbort = messaging.buildRequestMessage(messaging.messageType.updaterInstallAbort);
    return this.sendMessage(updaterAbort, 'updaterInstallAbort');
  }

  putUpdaterInstall(type, installSigs, installGeo, xmlMessage) {
    if (!config.get('appwall.connectToProtocol')) {
      log.info('Dev Mode: canned response to putUpdaterInstall');
      const cannedMessage = {
        resultCode: 200, // A sample return of a 200 status - with the error in the message
      };
      return Promise.resolve(cannedMessage);
    }

    let toInstall = (installSigs) ? ',1' : ',0';
    toInstall = (installGeo) ? toInstall + ',1' : toInstall + ',0';

    if (type === 'InstallLocal') {
      const installLocal = messaging.buildRequestMessage(
        messaging.messageType.updaterInstallLocal, 'LOCALINSTALL' + toInstall, xmlMessage);
      return this.sendMessage(installLocal, 'updaterInstallLocal');
    } else if (type === 'InstallVersion') {
      const installVer = messaging.buildRequestMessage(
        messaging.messageType.updaterInstallVersion, 'INSTALL' + toInstall, xmlMessage);
      return this.sendMessage(installVer, 'updaterInstallVersion');
    } else { // type === 'InstallLatest'
      const installLatest = messaging.buildRequestMessage(
        messaging.messageType.updaterInstallLatest, 'INSTALLLATEST' + toInstall);
      return this.sendMessage(installLatest, 'updaterInstallLatest');
    }
  }


  getDynamicServerStatus() {
    // TODO: centralize this better
    if (!config.get('appwall.connectToProtocol')) {
      log.info('Dev Mode: canned response to getDynamicServerStatus');
      const cannedData = fs.readFileSync(path.join(config.get('appwall.configFilePath'), 'ServerStatusDynamic.xml'));
      const cannedMessage = {
        messageBody: cannedData,
      };
      return Promise.resolve(cannedMessage);
    }

    const dynamicServerStatusMessage = messaging.buildRequestMessage(messaging.messageType.serverStatusDynamic);
    return this.sendMessage(dynamicServerStatusMessage, 'dynamicServerStatus');
  }

  getStaticServerStatus() {
    // TODO: centralize this better
    if (!config.get('appwall.connectToProtocol')) {
      log.info('Dev Mode: canned response to getStaticServerStatus');
      const cannedData = fs.readFileSync(path.join(config.get('appwall.configFilePath'), 'ServerStatusStatic.xml'));
      const cannedMessage = {
        messageBody: cannedData,
      };
      return Promise.resolve(cannedMessage);
    }

    const staticServerStatusMessage = messaging.buildRequestMessage(messaging.messageType.serverStatusStatic);
    return this.sendMessage(staticServerStatusMessage, 'staticServerStatus');
  }

  restartAppwall() {
    // TODO: centralize this better
    if (!config.get('appwall.connectToProtocol')) {
      log.info('Dev Mode: AppWall not really restarting.');
      const cannedMessage = {};
      return Promise.resolve(cannedMessage);
    }

    log.info('Sending restart server message to AppWall.');
    const restartAppWallMessage = messaging.buildRequestMessage(messaging.messageType.restartServer);
    return this.sendMessage(restartAppWallMessage, 'restartAppWall');
  }

  testConnection(xmlMessage) {
    if (!config.get('appwall.connectToProtocol')) {
      log.info('Dev Mode: canned response');
      const cannedMessage = {
        resultCode: 200,
        serverVersion: '7.5.1.1',
        headerMessage: 0,
      };
      return Promise.resolve(cannedMessage);
    }

    log.info('Sending Test Connection Message to Appwall');
    const testConnectionMessage = messaging.buildRequestMessage(messaging.messageType.testConnection, null, xmlMessage);
    return this.sendMessage(testConnectionMessage, 'testConnection');
  }

  getDataFileVersion(filterType) {
    if (!config.get('appwall.connectToProtocol')) {
      log.info('Dev Mode: canned response');
      const filterName = Object.keys(messaging.filterNumber).find((key) => messaging.filterNumber[key] === filterType);
      const cannedMessage = {
        resultCode: 503,
        headerMessage: filterName + ',7.5.1.1,' + filterName + '.dat,7.5.1.15',
      };
      return Promise.resolve(cannedMessage);
    }
    log.info('Sending message to AppWall');
    const getDataFileVersionMessage = messaging.buildRequestMessage(messaging.messageType.dataFileVersion, filterType);
    return this.sendMessage(getDataFileVersionMessage, 'dataFileVersion');
  }

  getFilterDetails(filterType, xmlMessage) {
    if (!config.appwall.connectToProtocol) {
      log.info('Dev Mode: Canned filter details');
      let cannedMessage = {
        resultCode: 200,
        serverVersion: '0.0.0.0',
        messageBody: '<Reply></Reply>',
      };

      if (filterType === 0) { // Vulnerabilities
        if (xmlMessage.match('6666')) { // Heavy-handed match that will pick up any 6666, but only for devs
          const cannedData = fs.readFileSync(path.join(config.appwall.configFilePath, 'VulnPatternDetails.xml'));
          cannedMessage = {
            messageBody: cannedData,
          };
        }
      }

      return Promise.resolve(cannedMessage);
    }

    // @TODO: This really needs to be tested against an actual AppWall!
    log.info('Sending filter details request to AppWall');
    const getFilterDetailsMessage = messaging.buildRequestMessage(messaging.messageType.filterDetails,
      filterType, xmlMessage);
    return this.sendMessage(getFilterDetailsMessage, 'filterDetails');
  }
}

module.exports = new AppWallCommunication();
