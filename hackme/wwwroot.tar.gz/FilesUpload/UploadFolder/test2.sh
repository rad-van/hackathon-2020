while :
do
declare -a curlArgs=('-H' "Content-Type: application/json" '-H' "55555: 4.15.16.17" )
#hackMe1
# Directory Listing with query
curl -s -i -m 2 --compressed --referer http://alteonhackmehost.com/ --user-agent \"AppleWebKit/53\" http://alteonhackmehost.com/DirectoryListing/
sleep 1
curl -s -i -m 2 --compressed --referer http://alteonhackmehost.com/ --user-agent \"AppleWebKit/53\" http://alteonhackmehost.com/DirectoryListing/
sleep 1
curl -s -i -m 2 --compressed --referer http://alteonhackmehost.com/ --user-agent \"AppleWebKit/53\" http://alteonhackmehost.com/DirectoryListing/
sleep 1
curl -s -i -m 2 --compressed --referer http://alteonhackmehost.com/ --user-agent \"AppleWebKit/53\" http://alteonhackmehost.com/DirectoryListing/
sleep 1
# HTTP Method HEAD
curl -I -s -i -m 2 --compressed --referer http://alteonhackmehost.com/ --user-agent \"AppleWebKit/53\" http://alteonhackmehost.com/SecurityPage/SecurityBlock.asp
sleep 1
# HTTP Method HEAD
curl -I -s -i -m 2 --compressed --referer http://alteonhackmehost.com/ --user-agent \"AppleWebKit/53\" http://alteonhackmehost.com/SecurityPage/SecurityBlock.asp
sleep 1

# Session - cookie poisoning with query
curl -s -i -m 2 --compressed --referer http://alteonhackmehost.com/ -H "Cookie: hacker=foo" --user-agent \"AppleWebKit/53\" http://alteonhackmehost.com/SecurityPage/SecurityBlock.asp
sleep 1
# Vulnerabilities URL Access Violation
curl -s -i -m 2 --compressed --referer http://alteonhackmehost.com/ --user-agent \"AppleWebKit/53\" http://alteonhackmehost.com/
sleep 1
curl -s -i -m 2 --compressed --referer http://alteonhackmehost.com/ --user-agent \"AppleWebKit/53\" http://alteonhackmehost.com/
sleep 1

# XML Security Invalid POST
curl -s -i -m 2 -X POST -H "Accept: text/xml" -H "Content-Type: text/xml" -d "<foo" --user-agent \"AppleWebKit/53\" http://alteonhackmehost.com/HacmeBank_V2_Website/aspx/login.aspx
sleep 1
curl -s -i -m 2 --compressed --referer http://alteonhackmehost.com/ --user-agent \"AppleWebKit/53\" http://alteonhackmehost.com/HacmeBank_V2_Website/aspx/login.aspx/HacmeBank_V2_Website/aspx/login.aspx
sleep 1
# Vulnerabilities - Server Info Leakage
curl -s -i -m 2 --compressed --referer http://alteonhackmehost.com/ --user-agent \"AppleWebKit/53\" http://alteonhackmehost.com/SafeReplyTest/ccn.txt
sleep 1
# SafeReply - CreditCard number Leakage
curl -s -i -m 2 --compressed --referer http://alteonhackmehost.com/ --user-agent \"AppleWebKit/53\" http://alteonhackmehost.com/SafeReplyTest/ccn.txt
sleep 1
curl -s -i -m 2 --compressed --referer http://alteonhackmehost.com/ --user-agent \"AppleWebKit/53\" http://alteonhackmehost.com/SafeReplyTest/ccn.txt
sleep 1

# Database SQL injection
curl -s -i -m 2 --compressed --referer http://alteonhackmehost.com/ --user-agent \"AppleWebKit/53\" http://alteonhackmehost.com/HacmeBank_V2_Website/aspx/login.aspx
sleep 1
#XSS Attack 
curl -s -i -m 2 --compressed --referer http://alteonhackmehost.com/ --user-agent \"AppleWebKit/53\" http://alteonhackmehost.com/index.php
sleep 1


done
