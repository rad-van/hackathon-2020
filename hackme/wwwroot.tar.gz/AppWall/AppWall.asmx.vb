﻿Imports System.Web.Services
Imports System.Web.Services.Protocols
Imports System.ComponentModel
Imports System.Data.SqlClient
Imports System.Xml
Imports AppWall.clsAppWall

' To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line.
' <System.Web.Script.Services.ScriptService()> _
<System.Web.Services.WebService(Namespace:="http://tempuri.org/")> _
<System.Web.Services.WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)> _
<ToolboxItem(False)> _
Public Class AppWallWS
    Inherits System.Web.Services.WebService


    Public Enum ErrorMess
        OK = 0
        NoFilesFoundForThisVer = 1
        NoNewVersionsForThisProduct = 2
        NotInSupportAgreement = 3
        GeneralError = 99
    End Enum
    Private sErrorDesc As String
    Private sReturnUrl As String
    Private objRetXML As New XmlDocument

    <WebMethod()> _
    Public Function Test() As String
        Return "Test OK: " & Now.ToString
    End Function
    ''' <summary>
    ''' Get the url for the lates ver. of the application product
    ''' </summary>
    ''' <param name="pMac">MAC address</param>
    ''' <param name="pProduct">product code, (eg. [AppWall])</param>
    ''' <param name="pSigVer">current installed signature ver (eg. 1.0.1)</param>
    ''' <param name="pSupport">check if in support (True/False)</param>
    ''' <param name="pApplicationVer">Application version (eg. 1.0.1)</param>
    ''' <returns>signature file URL or error.</returns>
    ''' <remarks></remarks>
    <WebMethod()> _
    Public Function GetFileUrl(ByVal pMac As String, ByVal pProduct As String, ByVal pSigVer As String, ByVal pSupport As Boolean, ByVal pApplicationVer As String) As XmlDocument
        Dim sSupportStatus As String = ""
        Dim objError As ErrorMess
        Dim sSigVer As String, sAppVer As String

        Try
            sSigVer = clsAppWall.ConvertVer2Save(pSigVer)
            sAppVer = clsAppWall.ConvertVer2Save(pApplicationVer)

            If pSupport Then sSupportStatus = checkSupport(pMac)

            If (LCase(sSupportStatus) = "active" And pSupport) Or Not (pSupport) Then
                objError = GetLatestVer(pProduct, sAppVer, sSigVer)
                Select Case objError
                    Case ErrorMess.OK
                        CreateError("")
                    Case ErrorMess.GeneralError
                        CreateError(sErrorDesc)
                    Case Else
                        CreateError(objError.ToString)
                End Select
            Else
                CreateError(ErrorMess.NotInSupportAgreement.ToString)
            End If

        Catch ex As Exception
            CreateError(ex.Message)
        Finally
        End Try
        Return objRetXML

    End Function

    ''' <summary>
    ''' Get list of the signature files to the application version (In case in support agreement).
    ''' </summary>
    ''' <param name="pMac">MAC address</param>
    ''' <param name="pProduct">product code,(eg. [AppWall])</param>
    ''' <param name="pApplicationVer">Application version (eg. 1.0.1)</param>
    ''' <param name="pSupport">check if in support (True/False)</param>
    ''' <returns>List of signature files for this application ver.</returns>
    ''' <remarks></remarks>
    <WebMethod()> _
    Public Function GelVerList(ByVal pMac As String, ByVal pProduct As String, ByVal pSupport As Boolean, ByVal pApplicationVer As String) As XmlDocument
        Dim sAppVer As String
        Dim sSupportStatus As String = ""

        Try
            sAppVer = clsAppWall.ConvertVer2Save(pApplicationVer)
            If pSupport Then sSupportStatus = checkSupport(pMac)
            If (LCase(sSupportStatus) = "active" And pSupport) Or Not (pSupport) Then
                Dim objCon As New SqlConnection
                Dim objCom As New SqlCommand
                Dim objDR As SqlDataReader
                Try
                    sReturnUrl = ""
                    objCon.ConnectionString = clsAppWall.ConnectionString
                    objCon.Open()

                    objCom.Connection = objCon
                    objCom.CommandType = CommandType.Text
                    objCom.CommandText = String.Format("SELECT ISN, CREATE_DATE,  URL, VERSION, FROM_VER, TO_VER, RELEASE_NOTE, IMPORTANCE, FILE_SIZE FROM AppWall " & _
                        "WHERE (PRODUCT = '{0}') AND (FLG_ACTIVE = 1) AND ('{1}' BETWEEN FROM_VER AND TO_VER  OR (FROM_VER = '' AND  TO_VER = '')) " & _
                        "ORDER BY CREATE_DATE DESC ", pProduct, sAppVer)
                    objDR = objCom.ExecuteReader
                    If objDR.HasRows Then
                        While objDR.Read
                            CreateAppWallXML(objDR!ISN, objDR!CREATE_DATE, objDR!URL, objDR!VERSION, objDR!RELEASE_NOTE, objDR!IMPORTANCE, objDR!FILE_SIZE)
                        End While
                    Else
                        CreateError(ErrorMess.NoFilesFoundForThisVer.ToString)
                    End If
                    objDR.Close()
                Catch ex As Exception
                    CreateError(ex.Message)
                Finally
                    objCon.Close()
                End Try
            Else
                CreateError(ErrorMess.NotInSupportAgreement.ToString)
            End If
        Catch ex As Exception
            CreateError(ex.Message)
        Finally

        End Try
        Return objRetXML
    End Function

    ''' <summary>
    ''' Add download result
    ''' </summary>
    ''' <param name="pIsn">Signature file ISN</param>
    ''' <param name="pMAC">MAC address</param>
    ''' <param name="pDownSucc">download status (True/False)</param>
    ''' <param name="pMngIp">the managed ip address</param>
    ''' <param name="pError">string decribes the error</param>
    ''' <returns>in case of error, returns XML</returns>
    ''' <remarks></remarks>
    <WebMethod()> _
    Public Function SetDownload(ByVal pIsn As Integer, ByVal pMAC As String, ByVal pDownSucc As Boolean, ByVal pMngIp As String, ByVal pError As String) As XmlDocument
        Dim objCon As New SqlConnection
        Dim objCom As New SqlCommand
        Try
            objCon.ConnectionString = ConnectionString()
            objCon.Open()
            objCom.Connection = objCon
            objCom.CommandType = CommandType.Text
            objCom.CommandText = String.Format("INSERT INTO AppWallDownload (VER_ISN, MAC_ADDRESS, DOWNLOAD_SUCCESS, MNG_IP, ERROR) " & _
                "VALUES ({0}, '{1}', '{2}', '{3}', '{4}')", pIsn, pMAC, pDownSucc, pMngIp, ReplaceGeresh(pError))
            objCom.ExecuteNonQuery()
            CreateError(ErrorMess.OK.ToString)
        Catch ex As Exception
            CreateError(ex.Message)
        Finally
            objCon.Close()
        End Try
        Return objRetXML
    End Function

    Private Function GetLatestVer(ByVal pApplication As String, ByVal pAppVer As String, ByVal pSigFileVer As String) As ErrorMess
        Dim objCon As New SqlConnection
        Dim objCom As New SqlCommand
        Dim objDR As SqlDataReader
        Try
            sReturnUrl = ""
            objCon.ConnectionString = ConnectionString()
            objCon.Open()

            objCom.Connection = objCon
            objCom.CommandType = CommandType.Text
            objCom.CommandText = String.Format("SELECT top 1 ISN, CREATE_DATE,  URL, VERSION, FROM_VER, TO_VER, RELEASE_NOTE, IMPORTANCE, FILE_SIZE FROM AppWall " & _
                "WHERE (PRODUCT = '{0}') AND (FLG_ACTIVE = 1) AND ('{1}' BETWEEN FROM_VER AND TO_VER  OR (FROM_VER = '' AND  TO_VER = '')) " & _
                "ORDER BY CREATE_DATE DESC ", pApplication, pAppVer)
            objDR = objCom.ExecuteReader
            If objDR.HasRows Then
                objDR.Read()
                CreateAppWallXML(objDR!ISN, objDR!CREATE_DATE, objDR!URL, objDR!VERSION, objDR!RELEASE_NOTE, objDR!IMPORTANCE, objDR!FILE_SIZE)
                If objDR!VERSION = pSigFileVer Then
                    Return ErrorMess.NoNewVersionsForThisProduct
                Else
                    sReturnUrl = objDR!URL
                    Return ErrorMess.OK
                End If
            Else
                Return ErrorMess.NoFilesFoundForThisVer
            End If
            objDR.Close()
        Catch ex As Exception
            sErrorDesc = ex.Message
            Return ErrorMess.GeneralError
        Finally
            objCon.Close()
        End Try

    End Function


    Private Function checkSupport(ByVal pMac As String) As String
        Dim objCon As New SqlConnection
        Dim objCom As New SqlCommand
        Dim RetVal As String
        Try
            sErrorDesc = ""
            objCon.ConnectionString = ConnectionString()
            objCon.Open()
            objCom.Connection = objCon
            objCom.CommandType = CommandType.Text

            objCom.CommandText = String.Format("SELECT isnull(SUPP_STT_STATUS,'') FROM installBase WHERE MAC_ADDRESS12 = '{0}'", pMac)
            RetVal = objCom.ExecuteScalar()
            If RetVal Is Nothing Then RetVal = ""
            Return RetVal
        Catch ex As Exception
            sErrorDesc = ex.Message
            Return ""
        Finally
            objCon.Close()
        End Try

    End Function

    Private Sub CreateAppWallXML(ByVal pIsn As Integer, ByVal pCreateDate As String, ByVal pUrl As String, ByVal pSigFileVer As String, ByVal pRelNote As String, ByVal pImport As String, ByVal pFileSize As String)
        If objRetXML.DocumentElement Is Nothing Then objRetXML.LoadXml("<Root></Root>")
        Dim objRoot As XmlNode = objRetXML.CreateElement("VER")

        Dim objChiled As XmlElement = objRetXML.CreateElement("CrateDate") : objChiled.InnerText = pCreateDate : objRoot.AppendChild(objChiled)
        Dim objChiled1 As System.Xml.XmlElement
        objChiled1 = objRetXML.CreateElement("URL") : objChiled1.InnerText = pUrl : objRoot.AppendChild(objChiled1)
        Dim objChiled2 As System.Xml.XmlElement
        objChiled2 = objRetXML.CreateElement("SignatureFileVer") : objChiled2.InnerText = ConvertVer2Display(pSigFileVer) : objRoot.AppendChild(objChiled2)
        Dim objChiled3 As System.Xml.XmlElement
        objChiled3 = objRetXML.CreateElement("RealeseNotes") : objChiled3.InnerText = pRelNote : objRoot.AppendChild(objChiled3)
        Dim objChiled4 As System.Xml.XmlElement
        objChiled4 = objRetXML.CreateElement("Importance") : objChiled4.InnerText = pImport : objRoot.AppendChild(objChiled4)
        Dim objChiled5 As System.Xml.XmlElement
        objChiled5 = objRetXML.CreateElement("ISN") : objChiled5.InnerText = pIsn : objRoot.AppendChild(objChiled5)
        Dim objChiled6 As System.Xml.XmlElement
        objChiled6 = objRetXML.CreateElement("SignatureFileSize") : objChiled6.InnerText = pFileSize : objRoot.AppendChild(objChiled6)
        objRetXML.DocumentElement.AppendChild(objRoot)
    End Sub

    Private Sub CreateError(ByVal pErrorString As String)
        If objRetXML.DocumentElement Is Nothing Then objRetXML.LoadXml("<Root></Root>")
        Dim objChiled As XmlNode = objRetXML.DocumentElement
        objChiled = objRetXML.CreateElement("Error") : objChiled.InnerText = pErrorString : objRetXML.DocumentElement.AppendChild(objChiled)
    End Sub
End Class