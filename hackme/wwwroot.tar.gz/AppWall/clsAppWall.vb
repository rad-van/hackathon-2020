﻿Public Class clsAppWall

    Public Shared Function ConnectionString() As String
        Return ConfigurationManager.ConnectionStrings("misCon").ConnectionString ' objConns.ConnectionStrings("misCon").ConnectionString
    End Function

    Public Shared Function ConvertVer2Save(ByVal pVer As String) As String
        Dim arry() As String, s As String, sRetVal As String = "", inx As Integer
        arry = Split(pVer & "...", ".")

        For inx = 0 To 2
            s = arry(inx)
            sRetVal += Right("0000" & s, 3) & "."
        Next
        If sRetVal = "000.000.000" Then sRetVal = ""

        'For Each s In arry
        '    sRetVal += Right("0000" & s, 3) & "."
        'Next
        sRetVal = Left(sRetVal, Len(sRetVal) - 1)   ' remove the . from the last position

        'If sRetVal = "000" Then sRetVal = ""
        Return sRetVal
    End Function


    Public Shared Function ConvertVer2Display(ByVal pVer As String) As String
        Dim arry() As String, s As String, sRetVal As String = ""
        arry = Split(pVer, ".")

        For Each s In arry
            sRetVal += Val(s) & "."
        Next
        sRetVal = Left(sRetVal, Len(sRetVal) - 1)   ' remove the . from the last position
        If sRetVal = "0" Then sRetVal = ""
        Return sRetVal
    End Function

    Public Shared Function ReplaceGeresh(ByVal sString2Check As String) As String
        Return Replace(sString2Check, "'", "''")
    End Function

End Class
