﻿Imports System.Data.SqlClient
Imports AppWall.clsAppWall

Partial Public Class AppWall
    Inherits System.Web.UI.Page

    Const sAppWall = "AppWall"
    Const sDownloadFolder = "C:\inetpub\wwwroot\Appwall\DownLoadFolder\"
    Const sMainURL = "http://idog-w7/appwall/DownLoadFolder/"
    Private sMisConString As String



    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'Dim objConns As New System.Configuration.ConnectionStringsSection
        sMisConString = clsAppWall.ConnectionString

        dsMain.ConnectionString = sMisConString
        dsProduct.ConnectionString = sMisConString
        dsDownloaded.ConnectionString = sMisConString
        dsClientList.ConnectionString = sMisConString


    End Sub

    Private Sub btnNew_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnNew.Click
        ClearValue()
        ShowUpdate(1)
    End Sub

    Function SaveNewVer() As Boolean
        Dim sSQL As String
        Dim objCon As New SqlConnection
        Dim objCom As New SqlCommand

        Try

            objCon.ConnectionString = sMisConString
            objCon.Open()
            objCom.Connection = objCon
            objCom.CommandType = CommandType.Text

            If lblIsn.Text = "" Then

                Dim sSaveFileName As String, sNewProduct As String, sUrl As String
                Dim sVer As String, sVerFrom As String, sVerTo As String, sFileSize As String
                sVer = ConvertVer2Save(txtVer.Text)
                sVerFrom = ConvertVer2Save(txtfromVer.Text)
                sVerTo = ConvertVer2Save(txtToVer.Text)

                If sVerFrom & sVerTo <> "" Then
                    'You can add rec. with no ver. range
                    If sVerFrom > sVerTo Then 'Or Not (sVer >= sVerFrom And sVer <= sVerTo) Then
                        ShowError2("please check version range")
                        Exit Try
                    End If
                End If

                If txtNewProdName.Text <> "" Then
                    sNewProduct = txtNewProdName.Text
                Else
                    sNewProduct = ddlNewProd.SelectedValue
                End If

                sUrl = sMainURL & fuFileUpload.FileName
                sSaveFileName = sDownloadFolder & fuFileUpload.FileName
                fuFileUpload.SaveAs(sSaveFileName)
                sFileSize = fuFileUpload.FileBytes.Length.ToString

                sSQL = String.Format("INSERT INTO AppWall (PRODUCT,  FILE_NAME, URL, VERSION, FLG_ACTIVE, FROM_VER, TO_VER, NOTE, RELEASE_NOTE, IMPORTANCE, FILE_SIZE)" & _
                        "VALUES('{0}','{1}' ,'{2}' ,'{3}' ,'{4}' ,'{5}' ,'{6}' ,'{7}' ,'{8}' ,'{9}','{10}' )", _
                        sNewProduct, fuFileUpload.FileName, sUrl, sVer, chkActive.Checked, sVerFrom, sVerTo, ReplaceGeresh(txtNote.Text), ReplaceGeresh(txtRelNote.Text), ddlImportance.SelectedValue, sFileSize)
            Else

                sSQL = String.Format("Update AppWall set FLG_ACTIVE='{0}', NOTE='{1}', RELEASE_NOTE='{2}', IMPORTANCE='{3}' where Isn='{4}' ", _
                                     chkActive.Checked, ReplaceGeresh(txtNote.Text), ReplaceGeresh(txtRelNote.Text), ddlImportance.SelectedValue, lblIsn.Text)
            End If
            objCom.CommandText = sSQL
            objCom.ExecuteNonQuery()
            Return True
        Catch ex As Exception
            ShowError2(ex.Message)
        Finally
            objCon.Close()
        End Try

    End Function

    Sub ClearValue()
        lblCreateDate.Text = ""
        lblFileName.Text = ""
        lblIsn.Text = ""
        lblFileSize.Text = ""
        txtfromVer.Text = "" : txtfromVer.ReadOnly = False
        txtNewProdName.Text = "" : txtNewProdName.ReadOnly = False
        txtNote.Text = ""
        txtRelNote.Text = ""
        txtToVer.Text = "" : txtToVer.ReadOnly = False
        txtVer.Text = "" : txtVer.ReadOnly = False
        ddlImportance.SelectedValue = "Medium" : ddlImportance.Enabled = True
        ddlNewProd.SelectedValue = sAppWall : ddlNewProd.Enabled = True
        chkActive.Checked = True
        lnkUrl.Text = ""
        trUpload.Visible = True
    End Sub
    Sub ShowUpdate(ByVal pType As Integer)
        pnlList.Style("filter") = "alpha(opacity=40)"
        pnlList.Enabled = False
        Select Case pType
            Case 1
                pnlUpdate.Visible = True
            Case 2
                pnlDownLoad.Visible = True
        End Select
    End Sub
    Sub ShowList()
        pnlUpdate.Visible = False
        pnlDownLoad.Visible = False
        pnlList.Style("filter") = "alpha(opacity=100)"
        pnlList.Enabled = True

    End Sub

 
 
    Sub ShowError(ByVal pErrorMess As String)
        cvError.ErrorMessage = pErrorMess
        If pErrorMess <> "" Then cvError.IsValid = False
    End Sub
    Sub ShowError2(ByVal pErrorMess As String)
        cvError2.ErrorMessage = pErrorMess
        If pErrorMess <> "" Then cvError2.IsValid = False
    End Sub

    Private Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click
        If SaveNewVer() Then
            ShowList()
            grdList.DataBind()
        End If
    End Sub

    Private Sub AppWall_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.PreRender
        If Not IsPostBack Then
            ddlProduct.SelectedValue = sAppWall
        End If

    End Sub

    Private Sub grdList_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles grdList.RowCommand
        Select Case e.CommandName
            Case "myDownLoad"
                lblIsn.Text = e.CommandArgument
                ShowUpdate(2)
            Case "myUpdate"
                Call UpdateSelectedRow(e.CommandArgument)
                ShowUpdate(1)
        End Select
    End Sub

    Private Sub grdList_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles grdList.RowDataBound
        Try

            Dim lblVer As Label
            lblVer = CType(e.Row.FindControl("lblVer"), Label)
            lblVer.Text = ConvertVer2Display(e.Row.DataItem("VERSION"))
        Catch ex As Exception

        End Try

    End Sub

    Sub UpdateSelectedRow(ByVal pSelectedIsn As Integer)
        Dim objCon As New SqlConnection, objcom As New SqlCommand, objDR As SqlDataReader
        Try
            objCon.ConnectionString = sMisConString
            objCon.Open()
            objcom.Connection = objCon
            objcom.CommandType = CommandType.Text
            objcom.CommandText = "select * from AppWall where ISN=" & pSelectedIsn
            objDR = objcom.ExecuteReader

            If objDR.HasRows Then
                With objDR
                    While .Read
                        txtNewProdName.ReadOnly = True
                        lblIsn.Text = !Isn.ToString
                        ddlNewProd.SelectedValue = !PRODUCT.ToString : ddlNewProd.Enabled = False
                        lblFileName.Text = !FILE_NAME.ToString
                        lnkUrl.NavigateUrl = !URL
                        lnkUrl.Text = !URL.ToString
                        txtVer.Text = ConvertVer2Display(!VERSION.ToString) : txtVer.ReadOnly = True
                        txtfromVer.Text = ConvertVer2Display(!FROM_VER.ToString) : txtfromVer.ReadOnly = True
                        txtToVer.Text = ConvertVer2Display(!TO_VER.ToString) : txtToVer.ReadOnly = True
                        chkActive.Checked = !FLG_ACTIVE
                        txtNote.Text = !NOTE
                        txtRelNote.Text = !RELEASE_NOTE
                        ddlImportance.SelectedValue = !IMPORTANCE : ddlImportance.Enabled = False
                        lblCreateDate.Text = !CREATE_DATE
                        lblFileSize.Text = "( " & !FILE_SIZE & " bytes )"
                        trUpload.Visible = False
                    End While
                End With
            End If

        Catch ex As Exception
            ShowError2(ex.Message)
        Finally
            objCon.Close()
        End Try
    End Sub

    Private Sub ddlSearchClient_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlSearchClient.TextChanged
        If ddlSearchClient.SelectedIndex <> 0 Then
            dsDownloaded.SelectCommand = String.Format("{0}  and OWNER='{1}' order by CREATE_DATE Desc", dsDownloaded.SelectCommand, ddlSearchClient.SelectedValue)
        End If

        dsDownloaded.DataBind()
        grdDownload.DataBind()
    End Sub

End Class