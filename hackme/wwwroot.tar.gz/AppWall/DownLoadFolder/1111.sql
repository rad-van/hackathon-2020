USE [MIS]

DECLARE @mac varchar(50)

SET @mac='8301FF9CC503'
declare @licenseType int 
SET @licenseType=0

	DECLARE @appPn varchar(1000), @upgradePn varchar(1000), @CONFIG_COMP_DESCR varchar(1000)
	set @appPn = ''
	set @upgradePn = ''
	set @CONFIG_COMP_DESCR = ''
	
	SELECT @CONFIG_COMP_DESCR = CONFIG_COMP_DESCR FROM installBase WHERE  MAC_ADDRESS12 like @mac
	
	--SELECT @appPn = @appPn + ',' + appPn FROM vaLgLog WHERE mac LIKE @mac AND appPn IS NOT NULL
	SELECT @appPn = @appPn + ',' + partNumber  FROM vaSn WHERE mac LIKE @mac AND componentType = 1 --AND rtrim(ltrim(oracleStatus)) <> 'UPDATED'
	--SELECT @upgradePn = @upgradePn + ',' + upgradePn FROM vaLgLog WHERE mac LIKE @mac AND upgradePn IS NOT NULL
	SELECT @upgradePn = @upgradePn + ',' + partNumber FROM vaSn WHERE mac LIKE @mac AND componentType = 2 AND rtrim(ltrim(oracleStatus)) <> 'UPDATED'
	SELECT @upgradePn = @upgradePn + ',' + SUBSTRING (ltrim(value),0,CHARINDEX(' ',ltrim(value)))  FROM dbo.f_Split(@CONFIG_COMP_DESCR, ';')

	select DISTINCT  rtrim(ltrim([Value])) AS pn ,ISNULL(lg.description,' - ') AS description ,1 AS pnType , functionality , vaSn.period 
	from dbo.f_Split( @appPn,',') pnTbl
		left outer JOIN  LG_items lg ON lg.part_number = rtrim(ltrim(pnTbl.[Value]))
		LEFT OUTER JOIN vaSn on lg.part_number = vaSn.partNumber
	WHERE [Value] <> ''	AND (@licenseType = 0 OR @licenseType = 1)
	UNION
	select DISTINCT  rtrim(ltrim([Value])) AS pn , ISNULL(lg.description,' - ')  AS description ,2 AS pnType ,  functionality , vaSn.period 
	from dbo.f_Split(@upgradePn,',') pnTbl
		left outer JOIN  LG_items lg ON lg.part_number = rtrim(ltrim(pnTbl.[Value]))
		LEFT OUTER JOIN vaSn on lg.part_number = vaSn.partNumber
	WHERE [Value] <> '' AND (@licenseType = 0 OR @licenseType = 2)


