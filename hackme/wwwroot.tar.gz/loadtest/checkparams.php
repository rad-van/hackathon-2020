<?php
  // 100ms
  $delay = 811 * 1000;
  usleep($delay);
  echo "?tt=awr&id={$_REQUEST['id']}&ac=0&p1=&p2=&p3=&df=1";
?>
