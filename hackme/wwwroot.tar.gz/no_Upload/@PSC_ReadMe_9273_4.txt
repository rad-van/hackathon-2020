Title: Upload file to web server
Description: This script will let you upload files to a web server very easily with 2 lines of source code and as little hassle as possible.
 

A demo (demo.asp) is included which explains everything you need to know, it is recommended you view this file first.

You can customize the upload directory, index to an access database, limit file sizes; I also demonstrate how to use the tool in a popup window if desired.

It should be acknowledged that most of the binary transfer work has been contributed
(special thanks, you know who you are).

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=9273&lngWId=4

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
