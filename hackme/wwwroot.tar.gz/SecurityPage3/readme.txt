Security page readme

1. Security page is for use with TMS demo
2. Security page is shown upon a policy violation
3. Is has to be placed on server in a directory name "error" under the root
4. 