function checkemail(email_address){
	if (email_address == "") {
		return false;
	}

	var filter = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i;
	return filter.test(email_address);
}

var req;
var url;
var prev;
var _qid;
var prevAnswer;
var editing = false;
var _st = "!~_!#__akb";
var keyctrl = false;
var keyshift = false;

/*
$(document).keydown(function (e) {
	if (e.which == 16) {
		keyctrl = true;
	} else if (e.which == 17) {
		keyshift = true;
	} else {
		if ((editing) && (e.which = 83) && (keyctrl) && (keyshift)) {
			saveContent(_qid);
		}
	}
});

$(document).keyup(function (e) {
	if (e.which == 16) {
		keyctrl = false;
	} else if (e.which == 17) {
		keyshift = false;
	}
});
*/
function addArticle (cid) {
    if (top.location.href.indexOf("categories") != -1) {
        var url_part = top.location.href.split('categories');
        var url_to_indexphp = url_part[0];
    } else {
        var url_to_indexphp = top.location.href;
    }
    var temp = url_to_indexphp + "admin/incadd_get.php?todo=__showadd&cid=" + cid;

    var customWidth = 750;
	var customHeight = 500;
    tb_show(JsAddQuestionTitle, temp + "&keepThis=true&height="+customHeight+"&width="+customWidth, "");
}

function SaveSuccess(responseStr) {
	var tarray = responseStr.split(_st);
	prev = tarray[0];
	prev2 = tarray[0];
	prevAnswer = tarray[1];
	prevStatus = tarray[2];
	restoreEditArticle();
	if (prevStatus == 're_pending') {
		document.getElementById("editArticle").innerHTML = '<span style="color: gray;">'+JsQuickEdit+'</span>&nbsp;';
		document.getElementById("editArticle").href = "javascript:alert(\'"+JsNoArticleEditPermission+"\');";
		document.getElementById("editArticleBackend").innerHTML = '<span style="color: gray;">'+JsQuestEdit+'</span>&nbsp;';
		document.getElementById("editArticleBackend").href = "javascript:alert(\'"+JsNoArticleEditPermission+"\');";
	}
	$('#successmesg').fadeIn();
}

function SaveFailure() {
	alert("There has been an error with your save data.\n\nPlease try again later");
}

function getTitle (qid) {
	var titleUrl = kbpath +'/admin/incedit_get.php';
	var titleSendData = 'id=' + qid + '&type=title';

	$.ajax({
		type: "GET",
		url: titleUrl,
		data: titleSendData,
		success: function(titleMsg){
			document.getElementById("title").innerHTML = '<input type="text" id="edTitle" name="title" value="' + titleMsg.replace(/\"/g,'&quot;') + '" class="dynText" />';
		}
	});

}

function editArticle(qid) {
	url = kbpath + '/admin/incedit_set.php';
	$('#mesg').fadeIn();
	$('#successmesg').hide();
	prev = getTitle (qid);

	prev2 = document.getElementById("title").innerHTML;
	prevAnswer = document.getElementById("answer").innerHTML;
	document.getElementById("editArticle").innerHTML = txtRestoreContent;
	document.getElementById("editArticle").href="javascript: restoreEditArticle();"
	document.getElementById("answer").innerHTML = '<iframe id="editorContainer" src="'+ kbpath +'/admin/incedit_get.php?id=' + qid + '&type=content" scrolling="no" style="padding: 0px; border: 0px solid black; width: 100%; height: 430px;" frameborder="0"></iframe><input type="button" value="' + txtSaveContent + '" class="qebutton qebold" onclick="javascript: saveContent(' + qid + ');" /> &nbsp; <input class="qebutton" type="button" onclick="javascript: restoreEditArticle();" value="' + txtRestoreContent + '" />';
	_qid = qid;
	editing = true;
}

function restoreEditArticle() {
	$('#mesg').hide();
	document.getElementById("title").innerHTML = prev2;
	document.getElementById("answer").innerHTML = prevAnswer;
	document.getElementById("editArticle").innerHTML = txtQuickEdit;
	document.getElementById("editArticle").href = "javascript: editArticle(" + _qid + ");";
}

function saveContent(qid) {
	newTitle = document.getElementById("edTitle").value.replace(/&quot;/g,'"');
	tinyMCE = document.getElementById("editorContainer").contentWindow.tinyMCE;

	if (Application.WYSIWYGEditor.isWysiwygEditorActive()) {
		newAnswer = Application.WYSIWYGEditor.getContent();
	} else {
		ifObj = document.getElementById("editorContainer").contentWindow;
		newAnswer = ifObj.document.getElementById("contentPlainText").value;
	}

	sendData = "id=" + qid + "&title=" + encodeURIComponent(newTitle) + "&answer=" + encodeURIComponent(newAnswer);

	$.ajax({
		type: "POST",
		url: url,
		data: sendData,
		success: function(msg){
			SaveSuccess(msg);
		}
	});
}

function ShowHelp(img, title, desc)
{
	div = document.createElement('div');
	div.id = 'help';

	div.style.display = 'inline';
	div.style.position = 'absolute';
	div.style.width = '190px';


	div.style.backgroundColor = '#FEFCD5';
	div.style.border = 'solid 1px #E7E3BE';
	div.style.padding = '10px';
	div.innerHTML = '<span class="helpTip"><strong>' + title + '<\/strong><\/span><br /><img src="images/1x1.gif" width="1" height="5"><br /><div style="padding-left:10; padding-right:5" class="helpTip">' + desc + '<\/div>';

	img.parentNode.appendChild(div);
}

function HideHelp(img)
{
	div = document.getElementById('help');
	if (div) {
		img.parentNode.removeChild(div);
	}
}

var Application = {
	WYSIWYGEditor: {
		getContent: function() {
			return tinyMCE.activeEditor.getContent();
		},
		setContent: function(content) {
			tinyMCE.activeEditor.setContent(content);
		},
		isWysiwygEditorActive: function() {
			if (typeof(tinyMCE) != 'undefined' && tinyMCE.activeEditor != null) {
				return true;
			}
			return false;
		},
		insertText: function(text) {
			tinyMCE.activeEditor.execCommand('mceInsertContent',false, text);
		}
	}
}