/*
// +----------------------------------------------------------------------+
// | Copyright (c) 2004 Bitflux GmbH                                      |
// +----------------------------------------------------------------------+
// | Licensed under the Apache License, Version 2.0 (the "License");      |
// | you may not use this file except in compliance with the License.     |
// | You may obtain a copy of the License at                              |
// | http://www.apache.org/licenses/LICENSE-2.0                           |
// | Unless required by applicable law or agreed to in writing, software  |
// | distributed under the License is distributed on an "AS IS" BASIS,    |
// | WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or      |
// | implied. See the License for the specific language governing         |
// | permissions and limitations under the License.                       |
// +----------------------------------------------------------------------+
// | Author: Bitflux GmbH <devel@bitflux.ch>                              |
// +----------------------------------------------------------------------+

*/
var liveSearchReq = false;
var t = null;
var liveSearchLast = "";
var isIE = false;
var frmName = 'frmSearch';
var fieldName = 'livesearch';
var highlight = null;
// on !IE we only have to initialize it once
if (window.XMLHttpRequest) {
	liveSearchReq = new XMLHttpRequest();
}

window.onload = function () { liveSearchInit(); }

function liveSearchInit() {
	f = document.getElementById(fieldName);
	if (f) {
		if (navigator.userAgent.indexOf("Safari") > 0) {
			f.addEventListener("keydown",liveSearchKeyPress,false);
			f.setAttribute("autocomplete","off");
		} else if (navigator.product == "Gecko") {
			f.addEventListener("keypress",liveSearchKeyPress,false);
			f.setAttribute("autocomplete","off");
		} else {
			f.attachEvent('onkeydown',liveSearchKeyPress);
			isIE = true;
			f.setAttribute("autocomplete","off");
		}
	}
}

function liveSearchKeyPress(event) {
	if (event.keyCode == 40 ) {
		//KEY DOWN
		highlight = document.getElementById("LSHighlight");
		if (!highlight) {
			highlight = document.getElementById("LSRes").firstChild;
		} else {
			highlight.removeAttribute("id");
			highlight = highlight.nextSibling;
		}
		if (highlight) {
			highlight.setAttribute("id","LSHighlight");
		}
		if (!isIE) { event.preventDefault(); }
	} else if (event.keyCode == 38 ) {
		//KEY UP
		highlight = document.getElementById("LSHighlight");
		if (!highlight) {
			highlight = document.getElementById("LSRes").lastChild;
		} else {
			highlight.removeAttribute("id");
			highlight = highlight.previousSibling;
		}
		if (highlight) {
				highlight.setAttribute("id","LSHighlight");
		}
		if (!isIE) { event.preventDefault(); }
	} else if (event.keyCode == 27) {
		//ESC
		highlight = document.getElementById("LSHighlight");
		if (highlight) {
			highlight.removeAttribute("id");
		}
		document.getElementById("LSResult").style.display = "none";
	}
}
function liveSearchStart() {
	f = document.getElementById(fieldName);
	if (f.value.length > 1) {
		if (t) {
			window.clearTimeout(t);
		}
		t = window.setTimeout("liveSearchDoSearch()",500);
	}
}

function liveSearchDoSearch() {
	f = document.getElementById(fieldName);
	if (liveSearchLast != f.value) {
		if (liveSearchReq && liveSearchReq.readyState < 4) {
			liveSearchReq.abort();
		}
		if ( f.value == "") {
			document.getElementById("LSResult").style.display = "none";
			highlight = document.getElementById("LSHighlight");
			if (highlight) {
				highlight.removeAttribute("id");
			}
			return false;
		}
		if (window.XMLHttpRequest) {
		// branch for IE/Windows ActiveX version
		} else if (window.ActiveXObject) {
			liveSearchReq = new ActiveXObject("Microsoft.XMLHTTP");
		}
		liveSearchReq.onreadystatechange= liveSearchProcessReqChange;
		liveSearchReq.open("GET", baseUrl + "/xmlsearch.php?type=livesearch&q=" + f.value);
		liveSearchLast = f.value;
		liveSearchReq.send(null);
	}
}

function liveSearchProcessReqChange() {
	if (liveSearchReq.readyState == 1) {
		showSearchingIcon();
	}
	if (liveSearchReq.readyState == 4) {
		var  res = document.getElementById("LSResult");
		if (liveSearchReq.responseText != '') {
			res.firstChild.innerHTML = liveSearchReq.responseText;
			if (isIE) addHover(res.firstChild);
			if (liveSearchReq.responseText.indexOf('LSRow') > -1) {
				res.style.display = "block";
			} else {
				res.style.display = "none";
			}

		}
		setTimeout('hideSearchingIcon()', 500);
	}
}

function liveSearchSubmit() {
	var highlight = document.getElementById("LSHighlight");
	if (highlight && highlight.firstChild.firstChild) {
		keyword = highlight.firstChild.firstChild.nodeValue;
		document.getElementById('livesearch').value = keyword;
		document.forms.frmSearch.action = baseUrl + searchUrl + realescape(keyword);
		highlight.removeAttribute("id");
		liveSearchLast = keyword;
		closeResults();
		document.forms.frmSearch.submit();
		return false;
	} else {
		keyword = document.getElementById('livesearch').value;
		document.forms.frmSearch.action = baseUrl + searchUrl + realescape(keyword);
		return true;
	}
}

function realescape(urlstr) {
	urlstr = encodeURIComponent(urlstr);
	
	urlstr = urlstr.replace("/\+/","%2B");
	urlstr = urlstr.replace("/\*/","%2A");
	urlstr = urlstr.replace("/\(/","%28");
	urlstr = urlstr.replace("/\)/","%29");
	
	return urlstr;
}

function closeResults() {
	document.getElementById("LSResult").style.display = "none";
}

function hideSearchingIcon() {
	if (document.getElementById('imgSearching')) {
		document.getElementById('imgSearching').style.display = 'none';
	}
	if (document.getElementById('imgNotSearching')) {
		document.getElementById('imgNotSearching').style.display = 'inline';
	}
}

function showSearchingIcon() {
	if (document.getElementById('imgSearching')) {
		document.getElementById('imgSearching').style.display = 'inline';
	}
	if (document.getElementById('imgNotSearching')) {
		document.getElementById('imgNotSearching').style.display = 'none';
	}
}

function addHover(start) {
	for (i=0; i<start.firstChild.childNodes.length; i++) {
		if (start.firstChild.childNodes[i].className == 'LSRow') {
			start.firstChild.childNodes[i].onmouseover=function() {
				this.className+="_over";
				if (highlight) {
					highlight.removeAttribute("id");
				}
			}
			start.firstChild.childNodes[i].onmouseout=function() {
				this.className=this.className.replace("_over", "");
			}
		}
	}
}

