Title: ASP Login and registration page. Uses database
Description: My first ASP project: a login page. It uses a database to verify usernames and passwords. Also includes registration ability. 
Comment is supplied so that less experienced programmers can also understand the code.
PLEASE VOTE IF YOU LIKE THIS CODE!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=7206&lngWId=4

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
